USA, 14 Sep 2023

IBM agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Brad Topol btopol@us.ibm.com https://github.com/bradtopol

List of contributors:

Ludovic Gasc ludovic.gasc@be.ibm.com https://github.com/ludovic-gasc
