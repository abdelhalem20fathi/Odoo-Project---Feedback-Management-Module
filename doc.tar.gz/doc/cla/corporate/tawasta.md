Finland, 2017-07-17

Oy Tawasta OS Technologies Ltd. agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

We declare that we are authorized and able to make this agreement and sign this declaration.

Signed,

    Jarmo Kortetjärvi jarmo.kortetjarvi@tawasta.fi https://github.com/jarmokortetjarvi

List of contributors:

    Aleksi Savijoki aleksi.savijoki@tawasta.fi https://github.com/savijoki
    Jarmo Kortetjärvi jarmo.kortetjarvi@tawasta.fi https://github.com/jarmokortetjarvi
