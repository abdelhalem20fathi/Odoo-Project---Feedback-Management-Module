Belgium, 2020-08-04

Logicasoft agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Olivier Laurent olivier.laurent@logicasoft.eu https://github.com/olilau

List of contributors:

Olivier Laurent olivier.laurent@logicasoft.eu https://github.com/olilau
Jean-Christophe Perrot jean-christophe.perrot@logicasoft.eu https://github.com/JCPERROT
Jonathan Giacomello jonathan.giacomello@logicasoft.eu https://github.com/GiacoJona
François Falmagne francois.falmagne@logicasoft.eu https://github.com/GreyShim
Andrea Ulliana andrea.ulliana@logicasoft.eu https://github.com/kea14
Nadège Grandjean nadege.grandjean@logicasoft.eu https://github.com/ngrandjean
Yvan DOTET yvan.dotet@logicasoft.eu https://github.com/YvanDotet

