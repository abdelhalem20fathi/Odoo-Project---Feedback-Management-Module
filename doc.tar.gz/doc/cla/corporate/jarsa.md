México,2015-09-23

Jarsa agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Alan Ramos  alan.ramos@jarsa.com.mx https://github.com/alan196

List of contributors:

Alan Ramos alan.ramos@jarsa.com.mx https://github.com/alan196
Luis Triana luis.triana@jarsa.com.mx https://github.com/xluiisx (up to date 2018-12-31)
Luis Triana luistriana.28@gmail.com https://github.com/xluiisx (up to date 2018-12-31)
Oscar Garza oscar.garza@jarsa.com.mx https://github.com/ougc27 (up to date 2018-12-31)
Alexis Reza alexis.reza@jarsa.com.mx https://github.com/AlexisReza (up to date 2018-12-31)
Isabel Esparza isabel.esparza@jarsa.com.mx https://github.com/IsabelEsparza (up to date 2018-12-31)
Miguel Ruiz miguel.ruiz@jarsa.com.mx https://github.com/lmgr0312
Sarai Osorio sarai.osorio@jarsa.com.mx https://github.com/SaraiOsorio (up to date 2018-12-31)
Vicente Alcala jesus.alcala@jarsa.com.mx https://github.com/jesus01x
Juventino Villegas juventino.villegas@jarsa.com.mx https://github.com/tino480
