Hungary, 2023-05-24

OdooTech Zrt. agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Csaba Tóth csaba.toth@odootech.hu https://github.com/tsabi

List of contributors:

Csaba Tóth csaba.toth@odootech.hu https://github.com/tsabi
Krisztián Juhász juhasz.krisztian@odootech.hu https://github.com/odootechnology
