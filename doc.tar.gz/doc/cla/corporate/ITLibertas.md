Russia, 2015-08-14

IT Libertas agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

IT Libertas LLC info@itlibertas.com https://github.com/itlibertas

List of contributors:

Denis Baranov baranov@itlibertas.com https://github.com/barachka
Tatiana Deribina deribina@itlibertas.com https://github.com/Sapfiriana
Aleksandr Shevelev shevelev@itlibertas.com https://github.com/alexalv
