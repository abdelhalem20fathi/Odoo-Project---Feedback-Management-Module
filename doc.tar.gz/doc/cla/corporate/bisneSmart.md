Spain, March 11, 2016

bisneSmart S.C. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

bisneSmart S.C. hola@bisnesmart.com https://github.com/bisnesmart

List of contributors:

Gonzalo Borrás Beta gborras@bisnesmart.com https://github.com/gonxi
Rubén Cabrera Martínez rcabrera@bisnesmart.com https://github.com/rubencabrera
