France, 2015-10-16

OpenFire Sarl agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Christian Moreau christian.moreau@openfire.fr https://github.com/cm-openfire

List of contributors:

Christian Moreau christian.moreau@openfire.fr https://github.com/cm-openfire
Cédric Le Brouster cedric.lebrouster@openfire.fr https://github.com/clb-openfire
Gwenaël D'Aubenton gwenael.daubenton@openfire.fr https://github.com/gd-openfire

