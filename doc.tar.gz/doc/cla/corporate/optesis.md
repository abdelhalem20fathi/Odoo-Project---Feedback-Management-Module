Senegal, 2020-08-18

Optesis SA agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Ibrahima GUEYE 44674493+optesis-ibg@users.noreply.github.com https://github.com/optesis-ibg

List of contributors:

Ibrahima GUEYE 44674493+optesis-ibg@users.noreply.github.com https://github.com/optesis-ibg
Anta NIANG 51160361+optesis-ang@users.noreply.github.com https://github.com/optesis-ang
Mame Abdoul Aziz SY 149785030+optesis-msy@users.noreply.github.com https://github.com/optesis-msy
