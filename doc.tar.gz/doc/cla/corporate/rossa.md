Paraguay, 2015-07-09

Rossa S.A. agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Rossa S.A. emaildarossa@gmail.com https://github.com/rossasa

List of contributors:

Marcelo Pickler marcelo@rossa.com.py https://github.com/loxamir
Alan R. S. Pieske alan@rossa.com.py https://github.com/alanpy
