Brazil, 2020-09-08

Escodoo agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Marcel Savegnago marcel.savegnago@escodoo.com.br https://github.com/escodoo


List of contributors:

Marcel Savegnago marcel.savegnago@escodoo.com.br https://github.com/marcelsavegnago 

Eduardo Aparício eduardo.aparicio@escodoo.com.br https://github.com/eduaparicio
