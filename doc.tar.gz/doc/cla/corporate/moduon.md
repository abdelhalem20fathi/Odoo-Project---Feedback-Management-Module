Spain, 2021-01-04

Moduon Team S.L. agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Rafael Blasco rblasco@moduon.team https://github.com/rafaelbn

List of contributors:

Jairo Llopis jairo@moduon.team https://github.com/Yajo
Eduardo De Miguel edu@moduon.team https://github.com/Shide
moduonbot moduonbot@moduon.team https://github.com/moduonbot
Rafael Blasco rblasco@moduon.team https://github.com/rafaelbn
Andrea Cattalani andrea@moduon.team https://github.com/anddago78
Emilio Pascual emilio@moduon.team https://github.com/emiliopascual
