Slovakia, 11.12.2020

26HOUSE agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed, 

Dominik Kertys dominik.kertys@26house.com https://github.com/dominikkertys

List of contributors:

Dominik Kertys dominik.kertys@26house.com https://github.com/dominikkertys

Andrej Nagy andrej.nagy@vdp.sk https://github.com/AndrejNagy

Tomáš Mačaj tomas.macaj@26house.com https://github.com/tom-m-26h

Shared account github@26house.com https://github.com/26houseRobot

Shared account private email 56382927+26houseRobot@users.noreply.github.com https://github.com/26houseRobot
