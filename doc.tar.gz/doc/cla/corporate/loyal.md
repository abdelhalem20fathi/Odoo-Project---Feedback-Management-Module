China, 2015-03-13

Loyal agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Kevin Wang kevin_327@163.com https://github.com/kevin3274

List of contributors:

Kevin Wang kevin@loyal-info.com https://github.com/kevin3274
