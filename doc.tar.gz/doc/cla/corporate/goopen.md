Slovenia, 2016-09-05

GoOpen, računalniške storitve, Aleš Ferlan s.p. agrees to the terms of the
Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Aleš Ferlan alefer89@protonmail.com

List of contributors:

Aleš Ferlan alefer89@gmail.com https://github.com/Alko89
Aleš Ferlan alefer89@protonmail.com
