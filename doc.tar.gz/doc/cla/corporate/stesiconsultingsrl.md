Italy, 07/03/2023

STeSI Consulting srl agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Francesco Moccia moccia.f@stesi.eu https://github.com/stesifrancesco

List of contributors:

Michele Di Croce dicroce.m@stesi.eu https://github.com/micheledic
Francesco Moccia moccia.f@stesi.eu https://github.com/stesifrancesco
Arcadio Pinto pinto.a@stesi.eu https://github.com/ArcadioPinto
