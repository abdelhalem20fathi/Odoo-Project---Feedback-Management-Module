Switzerland, France, 2015-02-10

Camptocamp SA and Camptocamp SaS agrees to the terms of the Odoo Corporate 
Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this 
declaration.

Signed,

Luc Maurer luc.maurer@camptocamp.com https://github.com/camptocamp

List of contributors:

Luc Maurer luc.maurer@camptocamp.com https://github.com/lucmaurer
Joël Grand-Guillaume joel.grandguillaume@camptocamp.com https://github.com/jgrandguillaume
Guewen Baconnier guewen.baconnier@camptocamp.com https://github.com/guewen
Yannick Vaucher yannick.vaucher@camptocamp.com https://github.com/yvaucher
Yannick Payot yannick.payot@camptocamp.com https://github.com/yvaucher
Nicolas Bessi nicolas.bessi@camptocamp.com https://github.com/nbessi
Frédéric Clementi frederic.clementi@camptocamp.com https://github.com/fclementic2c
Laurent Meuwly laurent.meuwly@camptocamp.com https://github.com/laurentmeuwly
Vincent Renaville vincent.renaville@camptocamp.com https://github.com/vrenaville
Matthieu Dietrich matthieu.dietrich@camptocamp.com https://github.com/mdietrichc2c
Alexandre Fayolle alexandre.fayolle@camptocamp.com https://github.com/gurneyalex
Leonardo Pistone leonardo.pistone@camptocamp.com https://github.com/lepistone
Romain Deheele romain.deheele@camptocamp.com https://github.com/rdeheele
Maxime Wiot maxime.wiot@camptocamp.com https://github.com/maxime-c2c
Ferdinand Gassauer ferdinand.gassauer@camptocamp.com https://github.com/ferdiga
Jean-Baptiste Aubort jean-baptiste.aubort@camptocamp.com
Cyril Gaudin cyril.gaudin@camptocamp.com https://github.com/cyrilgdn
Denis Leemann denis.leemann@camptocamp.com https://github.com/leemannd
Akim Juillerat akim.juillerat@camptocamp.com https://github.com/grindtildeath
Damien Crier damien.crier@camptocamp.com https://github.com/damdam-s
Simone Orsi simahawk@gmail.com https://github.com/simahawk
Patrick Tombez patrick.tombez@camptocamp.com https://github.com/p-tombez
Julien Coux julien.coux@camptocamp.com https://github.com/jcoux
Alexandre Saunier alexandre.saunier@camptocamp.com https://github.com/asaunier
Frédéric Junod frederic.junod@camptocamp.com https://github.com/fredj
Sébastien Alix sebastien.alix@camptocamp.com https://github.com/sebalix
Thomas Nowicki thomas.nowicki@camptocamp.com https://github.com/Tonow-c2c
Telmo Santos telmo.santos@camptocamp.com https://github.com/santostelmo
Thierry Ducrest thierry.ducrest@camptocamp.com https://github.com/TDu
Stéphane Mangin stephane.mangin@camptocamp.com https://github.com/StephaneMangin
Anna Janiszewska anna.janiszewska@camptocamp.com https://github.com/ajaniszewska-dev
Matthieu Mequignon matthieu.mequignon@camptocamp.com https://github.com/mmequignon
Silvio Gregorini silvio.gregorini@camptocamp.com https://github.com/SilvioC2C
Iryna Vyshnevska iryna.vyshnevska@camptocamp.com https://github.com/i-vyshnevska
Ricardo Almeida Soares ricardo.almeidasoares@camptocamp.com https://github.com/Ricardoalso
Juan Miguel Sánchez Arce juan.sanchez@camptocamp.com https://github.com/JuMiSanAr
Maksym Yankin maksym.yankin@camptocamp.com https://github.com/yankinmax
Vincent Van Rossem vincent.vanrossem@camptocamp.com https://github.com/vvrossem
Victor Vermot-Petit-Outhenin victor.vermot@camptocamp.com https://github.com/victorvermot
Sarah Jallon sarah.jallon@camptocamp.com https://github.com/sarsurgithub
Ricardo Almeida Soares ricardo.almeidasoares@camptocamp.com https://github.com/ricardoalso
Italo Lopes italo.lopes@camptocamp.com https://github.com/imlopes
