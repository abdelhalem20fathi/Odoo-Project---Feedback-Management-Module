Ecuador, 15/03/2021

TRESCLOUD CÍA LTDA agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Andrés Calle andres.calle@trescloud.com https://github.com/pepetreshere

List of contributors:

Andrés Calle andres.calle@trescloud.com https://github.com/pepetreshere
Juan Álvarez juan.alvarez@trescloud.com https://github.com/JuanDanielAlvarez
Steven Luna steven.luna@trescloud.com https://github.com/stevTresCloud
Raúl Ruilova raul.ruilova@trescloud.com https://github.com/rrvc12
Angel Parra arpr18@gmail.com https://github.com/aparragithub
Ken Luzuriaga ken.luzuriaga@trescloud.com https://github.com/kenluzuriaga0