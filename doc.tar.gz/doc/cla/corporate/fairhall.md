Spain, 2017-06-12

Fairhall Solutions, S.L. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Harsh Sharma harsh@fairhall.es https://github.com/fairhall

List of contributors:

Carlos Mayo carlos.mayo@fairhall.es https://github.com/cmayo