Finland, 2019-11-22

Web-veistämö Oy (auxiliary business name Avoin.Systems) agrees to the terms of the Odoo Corporate
Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Miku Laitinen miku.laitinen@avoin.systems https://github.com/mlaitinen

List of contributors:

Miku Laitinen miku.laitinen@avoin.systems https://github.com/mlaitinen
Svante Suominen svante.suominen@avoin.systems https://github.com/svantesuominen
Erno Iipponen erno.iipponen@avoin.systems https://github.com/iipponen
Tuomo Aura tuomo.aura@avoin.systems https://github.com/tuomoaura
Atte Isopuro atte.isopuro@avoin.systems https://github.com/aisopuro
Mikko Närjänen mikko.narjanen@avoin.systems https://github.com/mtnarjan
Santeri Valjakka santeri.valjakka@avoin.systems https://github.com/hegenator
Oskars Zālītis oskars.zalitis@avoin.systems https://github.com/n17
Emīls Goško emils.gosko@avoin.systems https://github.com/EmailsGmails
Daniels Andersons daniels.andersons@avoin.systems https://github.com/Menestrels
Tatiana Deribina tatiana.deribina@avoin.systems https://github.com/Tatider

