Germany, 2017-07-25

sewisoft UG agrees to the terms of the Odoo Corporate
Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this 
declaration.

Signed,

Günter Selbert guenter.selbert@sewisoft.de https://github.com/Guenzn

List of contributors:

Günter Selbert guenter.selbert@sewisoft.de https://github.com/Guenzn
Stefan Wild stefan.wild@sewisoft.de https://github.com/wildi1
