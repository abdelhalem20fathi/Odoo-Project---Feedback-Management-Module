France, 2015-04-08

Syleam agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Sylvain Garancher sylvain.garancher@syleam.fr https://github.com/sylvain-garancher

List of contributors:

Sébastien Lange sebastien.lange@syleam.fr https://github.com/alnslang
Sylvain Garancher sylvain.garancher@syleam.fr https://github.com/sylvain-garancher
Alexandre Moreau alexandre.moreau@syleam.fr https://github.com/a-moreau (Up to 2017-08-31)
Christopher Tribbeck chris.tribbeck@syleam.fr https://github.com/ctribbeck
Jérémy Cormier jeremy.cormier@syleam.fr https://github.com/Corbiezorq
Samuel Piquet samuel.piquet@syleam.fr https://github.com/sa3m
