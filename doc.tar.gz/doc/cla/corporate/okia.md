Belgium, 2018-11-05

Okia SPRL agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Sylvain Van Hoof sylvain@okia.be https://github.com/sylvainvh

List of contributors:

Sylvain Van Hoof sylvain@okia.be https://github.com/sylvainvh
