Canada, 2023-04-19

Bemade Inc. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Marc Durepos marc@bemade.org https://github.com/itdurpro/

List of contributors:

Marc Durepos marc@bemade.org https://github.com/itdurpro/
Benoît Vézina benoit@vezina.biz https://github.com/xtremxpert/
