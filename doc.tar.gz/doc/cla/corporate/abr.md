Canada, USA, 2016-03-04

Applied Brain Research agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Trevor Bekolay tbekolay@gmail.com https://github.com/tbekolay/

List of contributors:

Trevor Bekolay tbekolay@gmail.com https://github.com/tbekolay/
