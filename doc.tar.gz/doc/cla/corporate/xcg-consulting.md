France, 2023-09-14

XCG Consulting agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Florent Aide florent.aide@gmail.com https://github.com/faide

List of contributors:

Florent Aide florent.aide@gmail.com https://github.com/faide
Houzéfa Abbasbhay houzefa.abba@xcg-consulting.fr https://github.com/houzefa-abba
Vincent Hatakeyama vincent.hatakeyama@xcg-consulting.fr https://github.com/vincent-hatakeyama
