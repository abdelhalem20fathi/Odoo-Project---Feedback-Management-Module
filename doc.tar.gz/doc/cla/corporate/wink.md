Belgium, 2018-04-06

WINK SA/NV agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Thomas Fossoul tfossoul@wink.be https://github.com/tfossoulw

List of contributors:

Thomas Fossoul tfossoul@wink.be https://github.com/tfossoulw
