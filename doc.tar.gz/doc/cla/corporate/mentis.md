Slovenia, 2015-06-29

Mentis d.o.o. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Dušan Laznik dusan.laznik@mentis.si https://github.com/laznikd

List of contributors:

Dušan Laznik dusan.laznik@mentis.si https://github.com/laznikd
Aleksander Dirntiš sandi.dirntis@mentis.si https://github.com/adirntis
Matjaž Kalič matjaz.kalic@mentis.si https://github.com/kalicm
