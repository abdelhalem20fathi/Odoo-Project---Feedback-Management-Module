Switzerland, 2023-09-25

Abilium GmbH agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Severin Zumbrunn severin.zumbrunn@abilium.com  https://github.com/szumbrunn

List of contributors:

Severin Zumbrunn sz@tune-x.ch https://github.com/szumbrunn
