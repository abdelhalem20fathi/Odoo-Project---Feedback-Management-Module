Ecuador, 08/06/2020

OPA Consulting agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Guenael Labois  glabois@opa-consulting.com https://github.com/Stentor until 2021-07-31

List of contributors:

Guenael Labois  glabois@opa-consulting.com https://github.com/Stentor until 2021-07-31
Guenael Labois  glabois@h4o-studio.com https://github.com/Stentor until 2021-07-31
Christopher Ormaza cormaza@opa-consulting.com https://github.com/opa-cormaza
