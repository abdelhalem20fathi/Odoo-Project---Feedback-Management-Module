India, 2024-01-05

Sunarc Technologies agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Sunarc Technologies community@sunarctechnologies.com https://github.com/sunarcgithub

List of contributors:

Sunarc Technologies community@sunarctechnologies.com https://github.com/sunarcgithub
