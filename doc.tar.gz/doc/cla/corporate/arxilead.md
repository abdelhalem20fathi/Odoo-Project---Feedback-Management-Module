Portugal, 2019-08-13

Arxilead Tecnologia e Gestão Lda. agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Rita Santos rita.santos@arxi.pt https://github.com/Arxilead

List of contributors:

* Marcelo Pereira marcelo.pereira@arxi.pt https://github.com/marcelopereiraarxi
* Nuno Silva nuno.silva@arxi.pt https://github.com/nunosilvaarxi
* Reinaldo Ramos reinaldo.ramos@arxi.pt https://github.com/reinaldoramosarxi
* Tiago Santos tiago.santos@arxi.pt https://github.com/tiagosantosarxi
