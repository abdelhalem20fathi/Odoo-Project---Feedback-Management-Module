Switzerland, 2015-08-18

Compassion Switzerland agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this 
declaration.

Signed,

Emanuel Cino ecino@compassion.ch https://github.com/CompassionCH


List of contributors:

Emanuel Cino ecino@compassion.ch https://github.com/ecino
