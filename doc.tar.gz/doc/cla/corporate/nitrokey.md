Berlin 2022-08-08

Nitrokey agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Nitrokey info@nitrokey.com https://github.com/Nitrokey/odoo

List of contributors:

Nitrokey info@nitrokey.com https://github.com/Nitrokey/odoo
Isufi Kapasi isufi.kapasi@initos.com https://github.com/ikapasi-initos
Dhara Solanki dhara.solanki@initos.com https://github.com/dsolanki-initos
Jan Suhr jan@nitrokey.com https://github.com/jans23