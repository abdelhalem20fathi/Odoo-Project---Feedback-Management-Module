Russia, 2017-11-25

IT-Projects LLC agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Ivan Yelizariev https://github.com/yelizariev

List of contributors:

Ivan Yelizariev yelizariev@it-projects.info https://github.com/yelizariev
Ildar Nasyrov nasyrov@it-projects.info https://github.com/iledarn
Ilmir Karamov karamov@it-projects.info https://github.com/ilmir-k
Dinar Gabbasov gabbasov@it-projects.info https://github.com/GabbasovDinar
Artyom Losev losev@it-projects.info https://github.com/ArtyomLosev
Alexandr Kolushov kolushov@it-projects.info https://github.com/KolushovAlexandr
Rafis Bikbov bikbov@it-projects.info https://github.com/RafiZz
Eugene Molotov molotov@it-projects.info https://github.com/em230418
