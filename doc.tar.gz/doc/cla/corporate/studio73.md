Spain, 2021-03-23

Consultoria Informatica Studio73 S.L. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Pablo Fuentes pablo@studio73.es https://github.com/fuentes73

List of contributors:

Pablo Fuentes pablo@studio73.es https://github.com/fuentes73
Jordi Tolsa jordi@studio73.es https://github.com/jortolsa-s73
Ioan Galan ioan@studio73.es https://github.com/ioans73
Ethan Hildick ethan@studio73.es https://github.com/hildickethan-s73
Ferran Mora ferran@studio73.es https://github.com/ferran-s73
Carlos Reyes carlos@studio73.es https://github.com/reyes4711-s73
Miguel Gandia miguel@studio73.es https://github.com/miguel-s73
Roger Amorós roger@studio73.es https://github.com/rabbitjon-s73
Guillermo Llinares guillermo@studio73.es https://github.com/willerr-mo-s73
