United States, 2021-08-11

Bluemark agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Joseph Shusterman joseph@bluemark.com https://github.com/shusty

List of contributors:

John Wilson johnw@bluemark.com https://github.com/johnw-bluemark
Veli Kocak velik@bluemark.com https://github.com/velibm
