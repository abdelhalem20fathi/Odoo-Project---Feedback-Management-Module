Germany, 2019-03-27

Thought Gang GmbH agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Felix Hoßfeld <felix.hossfeld@thoughtgang.de> https://github.com/fhossfel

List of contributors:

Katrin Höyns <katrin.hoeyns@thoughtgang.de> https://github.com/khoeyns