Romania, 2020-04-02

NextERP Romania SRL agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Fekete Mihai-Adrian feketemihai@nexterp.ro https://github.com/feketemihai

List of contributors:

Fekete Mihai-Adrian feketemihai@nexterp.ro https://github.com/feketemihai
Horja Robert horjarobert@nexterp.ro https://github.com/horjarobert
Cojocaru Marcel cojocarumarcel@nexterp.ro https://github.com/mcojocaru
Teodor Alexandru teodoralexandru@nexterp.ro https://github.com/alexteodor
