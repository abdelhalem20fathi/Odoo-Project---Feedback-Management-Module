Finland, 2019-02-08

Sprint IT agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Elmeri Niemelä niemela.elmeri@gmail.com https://github.com/elmeriniemela

List of contributors:

Elmeri Niemelä niemela.elmeri@gmail.com https://github.com/elmeriniemela
Ivan Avdouevski ivan.avdouevski@sprintit.fi https://github.com/sprintit
Johan Tötterman johan.totterman@sprintit.fi https://github.com/juppe
Joonas Hartonen joonas.hartonen@sprintit.fi https://github.com/jhartonen
Roy Nurmi roy.nurmi@sprintit.fi 
Joakim Weckman joakim.weckman@sprintit.fi https://github.com/sprint-jweckman
