Romania, 2021-01-11

Bizi Software SRL agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Erik Ludescher erik@bizicloud.ro https://github.com/bizicloud-ro

List of contributors:

Erik Ludescher erik@bizicloud.ro https://github.com/bizicloud-ro
