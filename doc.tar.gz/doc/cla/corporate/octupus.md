Spain, 2024-08-28

Octupus Technologies S.L. agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Octupus Technologies S.L. sergio.gonzalez@octupus.es https://github.com/sergiogonzalez298

List of contributors:

Jesus Rabelo jrabelo@octupus.es https://github.com/rabeloj34

David Padilla dpadilla@octupus.es https://github.com/dpadilla2

Carlos García cgdiaz@octupus.es https://github.com/carlosgdiazgil

Beatriz Rivero beatriz.rivero@octupus.es https://github.com/bea-octupus

Andrés Ruiz a.ruiz@octupus.es https://github.com/aruizpuentes

Esteban Blanco ecamejo@octupus.es https://github.com/EstebanBlanc

Claribel Dominguez cdominguez@octupus.es https://github.com/clarybel

Esequiel Tamayo etamayo@octupus.es https://github.com/evazquez1983

Hector Estevez hestevez@octupus.es https://github.com/hestevez2020

Heyner Roque hroque@octupus.es https://github.com/hroque-octupus

Pastor Enrique pastor.enrique@octupus.es https://github.com/pastyenrique

Yhasmani Valdes yvaldes@octupus.es https://github.com/hachecito
