Switzerland, 2023-02-24

brain-tec AG agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Silvan Wyden silvan.wyden@braintec.com https://github.com/BT-swyden
Philipp Fux hilipp.fux@braintec.com https://github.com/BT-pfux

List of contributors:

Raul Martin raul.martin@braintec.com https://github.com/BT-rmartin
Frédéric Garbely frederic.garbely@braintec.com https://github.com/BT-fgarbely
Carlos Serra Toro carlos.serra@braintec.com https://github.com/BT-cserra
Cristian Rodriguez Navarro cristian.rodriguez@braintec.com https://github.com/BT-crodriguez
Olivier Jossen olivier.jossen@braintec.com https://github.com/BT-ojossen
Alberto Nieto alberto.nieto@braintec.com https://github.com/BT-anieto
