The Netherlands, 2021-04-14

Demolium BV agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

rconjour robin@conjour.nl https://github.com/rconjour

List of contributors:

rconjour robin@conjour.nl https://github.com/rconjour