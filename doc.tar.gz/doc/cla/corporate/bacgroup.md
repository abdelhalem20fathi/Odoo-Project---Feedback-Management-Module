Honduras, 2017-01-12

Business Analytics Consulting Group S.A. de C.V. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Leandro Gabriel Di Pasquale dipasquale@bacgroup.net https://github.com/leodipasquale

List of contributors:

Allan Daniel Aguilar Archaga aguilar@bacgroup.net https://github.com/allanaguilar
Dewin Javier Garcia Armijo garcia@bacgroup.net https://github.com/dewingarcia
Jose Reynaldo Cabrera Ayala cabrera@bacgroup.net https://github.com/jcabrera1990
Leandro Gabriel Di Pasquale dipasquale@bacgroup.net https://github.com/leodipasquale
Edwin Omar McClellan Salinas mcclellan@bacgroup.net https://github.com/prometeomcclellan
Osvaldo Jorge Gentile ogentile@bacgroup.net https://github.com/osvaldo35
Salvatore Josue Trimarchi Pinto trimarchi@bacgroup.net https://github.com/salvatoretrimarchi
