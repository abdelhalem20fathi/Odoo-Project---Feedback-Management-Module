Morocco, 2017-10-11

KAZACUBE SARL agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Damien DELANGLE ddelangle@kazacube.com https://github.com/kazacube-damien

List of contributors:

ddelangle@kazacube.com https://github.com/kazacube-damien
cloudmaster@kazacube.com https://github.com/sharecodekzc
