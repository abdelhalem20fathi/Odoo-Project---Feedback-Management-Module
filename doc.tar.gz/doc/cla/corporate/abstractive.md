Belgium, 2022-10-25

Abstractive BV agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this 
declaration.

Signed,

Vincent Baggerman vincent.baggerman@abstractive.be https://github.com/vincentius


List of contributors:

Vincent Baggerman vincent.baggerman@abstractive.be https://github.com/vincentius
Sibert Aerts sibert.aerts@abstractive.be https://github.com/Sibert-Aerts
Bart D'haese bart.dhaese@abstractive.be https://github.com/Bart-dh

