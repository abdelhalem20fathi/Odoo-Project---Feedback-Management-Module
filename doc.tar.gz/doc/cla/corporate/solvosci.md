Spain, 2020-02-15

Solvos Consultoría Informática S.L. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

David Alonso david.alonso@solvos.es https://github.com/dalonsod

List of contributors:

David Alonso david.alonso@solvos.es https://github.com/dalonsod
Luis Romero luis.romero@solvos.es https://github.com/lromero-solvos
Luisa Miguéns luisa.miguens@solvos.es https://github.com/lmiguens-solvos
