Denmark, 2022-04-03

Butikki agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Kjeld Borch Egevang kjeld@mail4us.dk https://github.com/Gitdyr

List of contributors:

Kjeld Borch Egevang kjeld@mail4us.dk https://github.com/Gitdyr
