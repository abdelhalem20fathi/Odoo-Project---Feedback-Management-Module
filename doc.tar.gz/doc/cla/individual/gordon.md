

gordon, 2022-7-14

I hereby agree to the terms of the Odoo Individual Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

gordon 54697960+filwu8@users.noreply.github.com https://github.com/filwu8
