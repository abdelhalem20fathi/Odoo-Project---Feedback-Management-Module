Vietnam, 2019-12-19

Vmax Ltd.Co agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Vmax admin@vmax.vn https://github.com/vmaxadmin

List of contributors:

Vmax admin@vmax.vn https://github.com/vmaxadmin
Minh Nguyen minhnguyen.vmax@gmail.com https://github.com/Minhvmax