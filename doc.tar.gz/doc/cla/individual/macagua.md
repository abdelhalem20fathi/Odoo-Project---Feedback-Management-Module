Venezuela, 09/12/2024

I hereby agree to the terms of the Odoo Individual Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Leonardo J. Caballero G. leonardocaballero@gmail.com https://github.com/macagua
