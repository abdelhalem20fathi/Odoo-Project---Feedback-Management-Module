United States, 2019 Oct 23

I hereby agree to the terms of the Odoo Individual Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Nathan Perry nateperry333@gmail.com https://github.com/servel333
