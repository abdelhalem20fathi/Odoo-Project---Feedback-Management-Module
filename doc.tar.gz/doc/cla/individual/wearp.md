United Kingdom, 2015-06-18

I hereby agree to the terms of the Individual Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and
sign this declaration.

Signed,

Will Earp will.earp@icloud.com https://github.com/wearp
