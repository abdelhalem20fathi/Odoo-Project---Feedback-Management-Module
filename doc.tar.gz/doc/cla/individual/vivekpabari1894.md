India, 2023-12-18

I hereby agree to the terms of the Odoo Individual Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Vivek Pabari vivekpabariwork@gmail.com https://github.com/vivekpabari1894
