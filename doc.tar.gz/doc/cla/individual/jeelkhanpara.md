India, July 29th, 2021

I hereby agree to the terms of the Odoo Individual Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Jeel Khanpara khanpara.jeel@gmail.com https://github.com/JeelBKhanpara
