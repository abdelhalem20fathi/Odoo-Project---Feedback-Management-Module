France, 2021-12-08

I hereby agree to the terms of the Odoo Individual Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Romaric PINSET LEPRETRE 81656154+romaric-oci@users.noreply.github.com https://github.com/romaric-oci
