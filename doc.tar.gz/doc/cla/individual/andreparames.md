Portugal, 2015-04-23

I hereby agree to the terms of the Odoo Individual Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

André Pereira github@andreparames.com https://github.com/andreparames
