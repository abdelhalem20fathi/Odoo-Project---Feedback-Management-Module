México, 2017-12-12

I hereby agree to the terms of the Odoo Individual Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Luis Ernesto García Medina ernesto.garcia@telematel.com https://github.com/ernesto-telematel